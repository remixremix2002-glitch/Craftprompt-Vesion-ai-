
import { GoogleGenAI } from "@google/genai";
import { Language, PromptResponse, Complexity } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Converts a File object to a Base64 string.
 */
const fileToGenerativePart = async (file: File): Promise<{ inlineData: { data: string; mimeType: string } }> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      // Remove the Data-URL prefix (e.g., "data:image/jpeg;base64,")
      const base64Data = base64String.split(',')[1];
      resolve({
        inlineData: {
          data: base64Data,
          mimeType: file.type,
        },
      });
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

const LANG_MAP: Record<Language, string> = {
  en: 'English',
  ar: 'Arabic',
  fr: 'French',
  ru: 'Russian',
  cs: 'Czech',
  es: 'Spanish',
  de: 'German',
  it: 'Italian',
  pt: 'Portuguese',
  zh: 'Chinese (Simplified)',
  ja: 'Japanese',
  ko: 'Korean',
  nl: 'Dutch',
  tr: 'Turkish',
  pl: 'Polish',
  hi: 'Hindi',
  vi: 'Vietnamese',
  th: 'Thai',
  id: 'Indonesian'
};

export const generateArtPrompt = async (
  imageFile: File, 
  language: Language, 
  isPremium: boolean = false,
  complexity: Complexity = 'standard',
  customStyle?: string
): Promise<PromptResponse> => {
  try {
    const imagePart = await fileToGenerativePart(imageFile);
    
    const targetLangName = LANG_MAP[language] || 'English';

    // Premium users get the more powerful Pro model for complex reasoning and detail
    // Standard users get the Flash model for speed and efficiency
    const modelName = isPremium ? 'gemini-3-pro-preview' : 'gemini-2.5-flash';

    let complexityInstructions = "";
    if (complexity === 'concise') {
      complexityInstructions = "Keep the main English prompt CONCISE and SHORT (approx 30-50 words). Focus only on the most critical subject and style elements.";
    } else if (complexity === 'standard') {
      complexityInstructions = "Provide a STANDARD length detailed prompt (approx 100-150 words). Cover subject, style, lighting, and composition.";
    } else if (complexity === 'detailed') {
      complexityInstructions = "Provide an EXTREMELY DETAILED and EXTENSIVE prompt (200+ words). Analyze every micro-detail, texture, lighting nuance, camera lens type, render engine parameters, and artistic techniques.";
    }

    const promptText = `
      Act as an expert art critic and AI prompt engineer. 
      Analyze the uploaded image.
      
      ${complexityInstructions}
      
      Your task is to provide:
      1. A text-to-image prompt in English that could be used to recreate this image using AI (like Midjourney or Stable Diffusion).
      ${language !== 'en' ? `2. A professional translation of that prompt into ${targetLangName}.` : ''}
      ${isPremium ? `3. THREE additional distinct variations of the prompt to reimagine the subject in different styles: 
         - Cinematic/Photorealistic
         - Anime/Illustration
         - Oil Painting/Classic Art` : ''}
      ${customStyle ? `4. A variation of the prompt specifically in the style of: "${customStyle}". Reinterpret the image's subject matter through this specific artistic lens.` : ''}
      
      Focus on:
      - Subject matter (what is happening).
      - Art Style (e.g., Cyberpunk, Renaissance, Ukiyo-e, Photorealistic, 3D Render).
      - Medium (e.g., Oil painting, Digital Art, Photography, Watercolor).
      - Lighting (e.g., Volumetric, Cinematic, Studio, Natural).
      - Color Palette.
      - Composition and Camera Angle.
      - Technical keywords (e.g., 8k, highly detailed, unreal engine 5 render).

      Return the result as a JSON object with the following structure:
      {
        "english": "The prompt...",
        "translated": ${language !== 'en' ? `"The ${targetLangName} translation..."` : "null"},
        "variations": ${isPremium ? `[
          {"style": "Cinematic", "prompt": "..."},
          {"style": "Anime", "prompt": "..."},
          {"style": "Oil Painting", "prompt": "..."}
        ]` : "null"},
        "customVariation": ${customStyle ? `{"style": "${customStyle}", "prompt": "..."}` : "null"}
      }
    `;

    const response = await ai.models.generateContent({
      model: modelName,
      contents: {
        parts: [
          imagePart,
          { text: promptText }
        ]
      },
      config: {
        responseMimeType: 'application/json'
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");

    return JSON.parse(text) as PromptResponse;
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    
    // Check for standard error properties from Google GenAI SDK or HTTP statuses
    const msg = error.message?.toLowerCase() || '';
    const status = error.status; // Often available in SDK errors or fetch responses

    // 429: Too Many Requests / Quota Exceeded
    if (status === 429 || msg.includes('quota') || msg.includes('429') || msg.includes('resource exhausted')) {
      throw new Error("QUOTA_EXCEEDED");
    }
    
    // 503 or generic overloading messages
    if (msg.includes('overloaded') || msg.includes('busy') || msg.includes('too many requests')) {
      throw new Error("RATE_LIMITED");
    }

    throw error;
  }
};

/**
 * Generates a video preview using Veo based on the prompt and input image.
 */
export const generateVideoPreview = async (
  prompt: string,
  imageFile: File | Blob
): Promise<string> => {
  // Always create a new instance for Veo to pick up selected API key from window context if needed
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  // Need to convert to base64 inline data manually as fileToGenerativePart expects File
  // but we might pass a Blob from the gallery
  let mimeType = 'image/png';
  let data = '';

  if (imageFile instanceof File) {
    const part = await fileToGenerativePart(imageFile);
    data = part.inlineData.data;
    mimeType = part.inlineData.mimeType;
  } else {
    // Handle Blob/Gallery Item
    const reader = new FileReader();
    const base64Promise = new Promise<string>((resolve, reject) => {
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(imageFile);
    });
    const result = await base64Promise;
    data = result.split(',')[1];
    mimeType = imageFile.type || 'image/png';
  }

  let operation = await ai.models.generateVideos({
    model: 'veo-3.1-fast-generate-preview',
    prompt: prompt,
    image: {
      imageBytes: data,
      mimeType: mimeType,
    },
    config: {
      numberOfVideos: 1,
      resolution: '720p',
      aspectRatio: '16:9' // Veo default/supported aspect
    }
  });

  // Polling loop
  while (!operation.done) {
    await new Promise(resolve => setTimeout(resolve, 5000));
    operation = await ai.operations.getVideosOperation({operation: operation});
  }

  if (operation.error) {
    throw new Error(operation.error.message);
  }

  const uri = operation.response?.generatedVideos?.[0]?.video?.uri;
  if (!uri) throw new Error("No video URI returned from generation");

  // Fetch the video content using the API key
  const response = await fetch(`${uri}&key=${process.env.API_KEY}`);
  const videoBlob = await response.blob();
  
  return URL.createObjectURL(videoBlob);
};
