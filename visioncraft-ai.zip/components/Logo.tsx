
import React from 'react';

export const Logo: React.FC<{ className?: string }> = ({ className = "w-10 h-10" }) => {
  return (
    <svg 
      viewBox="0 0 256 256" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg" 
      className={className}
      aria-label="App Logo"
    >
      <defs>
        {/* Main Body Gradient: Cyan to Purple */}
        <linearGradient id="mainGrad" x1="20" y1="20" x2="236" y2="236" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#06b6d4" /> {/* Cyan-500 */}
          <stop offset="50%" stopColor="#6366f1" /> {/* Indigo-500 */}
          <stop offset="100%" stopColor="#d946ef" /> {/* Fuchsia-500 */}
        </linearGradient>

        {/* Accent Gradient: Pink to Orange (Warmth) */}
        <linearGradient id="warmGrad" x1="200" y1="50" x2="50" y2="200" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#f43f5e" /> {/* Rose-500 */}
          <stop offset="100%" stopColor="#f59e0b" /> {/* Amber-500 */}
        </linearGradient>

        {/* Glow Filter for the center */}
        <filter id="centerGlow" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="8" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
        
        {/* Soft Shadow for depth */}
        <filter id="dropShadow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur in="SourceAlpha" stdDeviation="4" />
          <feOffset dx="2" dy="4" result="offsetblur" />
          <feComponentTransfer>
            <feFuncA type="linear" slope="0.3" />
          </feComponentTransfer>
          <feMerge>
            <feMergeNode in="offsetblur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {/* Outer Glow Ring */}
      <circle cx="128" cy="128" r="120" fill="url(#mainGrad)" opacity="0.05" />
      <circle cx="128" cy="128" r="90" stroke="url(#mainGrad)" strokeWidth="1" strokeOpacity="0.2" strokeDasharray="10 10" />

      {/* Main Dynamic Shape: Swirling Aperture Blades */}
      <g filter="url(#dropShadow)">
        {/* Blade 1 (Top Left) */}
        <path 
          d="M128 40 C 90 40, 60 70, 60 128 C 60 150, 68 170, 80 185 L 128 128 Z" 
          fill="url(#mainGrad)" 
          opacity="0.9"
        />
        {/* Blade 2 (Right) */}
        <path 
          d="M128 40 C 170 40, 210 80, 200 140 C 195 170, 170 200, 128 216 L 128 128 Z" 
          fill="url(#mainGrad)" 
          opacity="0.8"
        />
        {/* Blade 3 (Bottom Left Accent) */}
        <path 
          d="M60 128 C 60 170, 90 216, 128 216 C 110 180, 100 150, 128 128 Z" 
          fill="url(#warmGrad)" 
        />
      </g>

      {/* Central Iris / Lens */}
      <circle cx="128" cy="128" r="32" fill="#0f172a" />
      <circle cx="128" cy="128" r="26" fill="url(#mainGrad)" opacity="0.2" />
      
      {/* The Core Spark (The "Idea") */}
      <g filter="url(#centerGlow)">
        <path 
          d="M128 108 L 134 122 L 148 128 L 134 134 L 128 148 L 122 134 L 108 128 L 122 122 Z" 
          fill="white" 
        />
      </g>

      {/* Tech Accents (Orbiting dots) */}
      <circle cx="128" cy="30" r="4" fill="#06b6d4" opacity="0.6" />
      <circle cx="220" cy="128" r="3" fill="#d946ef" opacity="0.6" />
      <circle cx="60" cy="200" r="5" fill="#f59e0b" opacity="0.6" />

    </svg>
  );
};

export default Logo;
