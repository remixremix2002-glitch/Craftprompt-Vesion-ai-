
import React, { useState, MouseEvent, useRef } from 'react';
import { Maximize2, X, ZoomIn, Minimize2 } from 'lucide-react';

interface ZoomableImageProps {
  src: string;
  alt: string;
  className?: string;
}

const ZoomableImage: React.FC<ZoomableImageProps> = ({ src, alt, className = "" }) => {
  const [isHovered, setIsHovered] = useState(false);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [showLightbox, setShowLightbox] = useState(false);
  const [isLightboxZoomed, setIsLightboxZoomed] = useState(false);
  const imageRef = useRef<HTMLImageElement>(null);

  const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    if (!imageRef.current) return;
    const { left, top, width, height } = imageRef.current.getBoundingClientRect();
    const x = ((e.clientX - left) / width) * 100;
    const y = ((e.clientY - top) / height) * 100;
    setMousePos({ x, y });
  };

  const closeLightbox = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    setShowLightbox(false);
    setIsLightboxZoomed(false);
  };

  const toggleLightboxZoom = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsLightboxZoomed(!isLightboxZoomed);
  };

  return (
    <>
      <div 
        className={`relative overflow-hidden cursor-zoom-in group rounded-lg ${className}`}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        onMouseMove={handleMouseMove}
        onClick={() => setShowLightbox(true)}
      >
        <img 
          ref={imageRef}
          src={src} 
          alt={alt} 
          className="w-full h-auto object-cover transition-transform duration-200 ease-out will-change-transform"
          style={{
            transformOrigin: `${mousePos.x}% ${mousePos.y}%`,
            transform: isHovered ? 'scale(2.5)' : 'scale(1)',
          }}
        />
        
        {/* Hover Icon Indicator */}
        <div className="absolute top-2 right-2 bg-black/40 backdrop-blur-md p-1.5 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
          <Maximize2 className="w-4 h-4" />
        </div>
      </div>

      {/* Lightbox Modal */}
      {showLightbox && (
        <div 
          className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-sm animate-in fade-in duration-200"
          onClick={closeLightbox}
        >
          {/* Controls */}
          <div className="absolute top-0 left-0 w-full p-4 flex justify-end gap-3 z-[101] pointer-events-none">
             <div className="pointer-events-auto flex gap-2">
                <button 
                  className="p-2 bg-white/10 hover:bg-white/20 rounded-full text-white transition-colors backdrop-blur-md border border-white/10"
                  onClick={toggleLightboxZoom}
                  title={isLightboxZoomed ? "Fit to screen" : "View full resolution"}
                >
                  {isLightboxZoomed ? <Minimize2 className="w-6 h-6" /> : <ZoomIn className="w-6 h-6" />}
                </button>
                <button 
                  className="p-2 bg-white/10 hover:bg-white/20 rounded-full text-white transition-colors backdrop-blur-md border border-white/10"
                  onClick={closeLightbox}
                >
                  <X className="w-6 h-6" />
                </button>
             </div>
          </div>
          
          {/* Scrollable Container using Grid to center content regardless of size */}
          <div 
            className="w-full h-full overflow-auto grid place-items-center p-4"
          >
            <img 
              src={src} 
              alt={alt} 
              className={`
                transition-all duration-300 ease-in-out
                ${isLightboxZoomed 
                  ? 'max-w-none w-auto h-auto cursor-zoom-out' 
                  : 'max-w-full max-h-full object-contain cursor-zoom-in rounded-lg shadow-2xl'
                }
              `}
              onClick={toggleLightboxZoom}
            />
          </div>
        </div>
      )}
    </>
  );
};

export default ZoomableImage;
