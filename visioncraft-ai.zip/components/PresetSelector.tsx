
import React, { useState, useEffect, useRef } from 'react';
import { Bookmark, Save, Trash2, ChevronDown, Pencil, X } from 'lucide-react';
import { Language, Complexity, Preset, Translations } from '../types';
import { REGIONS } from '../constants';

interface Props {
  currentLanguage: Language;
  currentComplexity: Complexity;
  currentCustomStyle: string;
  onSelect: (preset: Preset) => void;
  onPresetsChange?: () => void;
  texts: Translations;
}

const PresetSelector: React.FC<Props> = ({ currentLanguage, currentComplexity, currentCustomStyle, onSelect, onPresetsChange, texts }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [presets, setPresets] = useState<Preset[]>([]);
  const [newPresetName, setNewPresetName] = useState('');
  
  // Editing state
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editLanguage, setEditLanguage] = useState<Language>('en');
  const [editComplexity, setEditComplexity] = useState<Complexity>('standard');
  const [editCustomStyle, setEditCustomStyle] = useState('');

  const dropdownRef = useRef<HTMLDivElement>(null);

  // Load presets from local storage on mount
  useEffect(() => {
    const saved = localStorage.getItem('prompt_extractor_presets');
    if (saved) {
      try {
        setPresets(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to parse presets", e);
      }
    }
  }, []);

  // Save to local storage whenever presets change
  const updatePresets = (newPresets: Preset[]) => {
    setPresets(newPresets);
    localStorage.setItem('prompt_extractor_presets', JSON.stringify(newPresets));
    if (onPresetsChange) {
      onPresetsChange();
    }
  };

  const handleSave = () => {
    if (!newPresetName.trim()) return;

    const newPreset: Preset = {
      id: Date.now().toString(),
      name: newPresetName.trim(),
      language: currentLanguage,
      complexity: currentComplexity,
      customStyle: currentCustomStyle
    };

    updatePresets([...presets, newPreset]);
    setNewPresetName('');
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    // If deleted item was being edited, cancel edit
    if (editingId === id) cancelEdit();
    updatePresets(presets.filter(p => p.id !== id));
  };

  const startEdit = (preset: Preset, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(preset.id);
    setEditName(preset.name);
    setEditLanguage(preset.language);
    setEditComplexity(preset.complexity);
    setEditCustomStyle(preset.customStyle || '');
  };

  const saveEdit = () => {
    if (!editingId || !editName.trim()) return;

    const updatedPresets = presets.map(p => {
      if (p.id === editingId) {
        return {
          ...p,
          name: editName.trim(),
          language: editLanguage,
          complexity: editComplexity,
          customStyle: editCustomStyle
        };
      }
      return p;
    });

    updatePresets(updatedPresets);
    setEditingId(null);
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditName('');
  };

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`
          flex items-center gap-2 px-3 py-1.5 rounded-md text-xs sm:text-sm font-medium transition-all duration-200
          ${isOpen ? 'bg-primary-100 dark:bg-primary-600/20 text-primary-600 dark:text-primary-400' : 'text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white hover:bg-gray-200 dark:hover:bg-dark-700'}
        `}
      >
        <Bookmark className="w-4 h-4" />
        <span>{texts.presetsLabel}</span>
        <ChevronDown className={`w-3 h-3 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="absolute top-full right-0 mt-2 w-80 bg-white dark:bg-dark-900 border border-gray-200 dark:border-dark-700 rounded-xl shadow-2xl z-50 p-4 animate-in fade-in slide-in-from-top-2">
          
          {editingId ? (
            // EDIT FORM
            <div className="flex flex-col gap-2 mb-4 bg-gray-50 dark:bg-dark-800 p-3 rounded-lg border border-primary-200 dark:border-primary-900/30">
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs font-bold text-primary-600 dark:text-primary-400">{texts.editPreset}</span>
                <button onClick={cancelEdit} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200">
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
              
              <input
                type="text"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                className="w-full bg-white dark:bg-dark-700 border border-gray-200 dark:border-dark-600 rounded px-2 py-1.5 text-xs sm:text-sm text-gray-900 dark:text-white focus:outline-none focus:border-primary-500"
                placeholder={texts.savePresetPlaceholder}
              />
              
              <div className="grid grid-cols-2 gap-2">
                 <select 
                   value={editLanguage} 
                   onChange={(e) => setEditLanguage(e.target.value as Language)}
                   className="w-full bg-white dark:bg-dark-700 border border-gray-200 dark:border-dark-600 rounded px-2 py-1.5 text-xs text-gray-900 dark:text-white focus:outline-none focus:border-primary-500"
                 >
                   {REGIONS.map(region => (
                     <optgroup label={region.region} key={region.region}>
                       {region.langs.map(lang => (
                         <option value={lang.code} key={lang.code}>{lang.label}</option>
                       ))}
                     </optgroup>
                   ))}
                 </select>
                 
                 <select 
                   value={editComplexity} 
                   onChange={(e) => setEditComplexity(e.target.value as Complexity)}
                   className="w-full bg-white dark:bg-dark-700 border border-gray-200 dark:border-dark-600 rounded px-2 py-1.5 text-xs text-gray-900 dark:text-white focus:outline-none focus:border-primary-500"
                 >
                   <option value="concise">{texts.complexShort}</option>
                   <option value="standard">{texts.complexNormal}</option>
                   <option value="detailed">{texts.complexLong}</option>
                 </select>
              </div>

              <input
                type="text"
                value={editCustomStyle}
                onChange={(e) => setEditCustomStyle(e.target.value)}
                className="w-full bg-white dark:bg-dark-700 border border-gray-200 dark:border-dark-600 rounded px-2 py-1.5 text-xs sm:text-sm text-gray-900 dark:text-white focus:outline-none focus:border-primary-500"
                placeholder={texts.customStyleLabel}
              />

              <button
                onClick={saveEdit}
                disabled={!editName.trim()}
                className="w-full mt-1 bg-primary-600 hover:bg-primary-500 text-white py-1.5 rounded text-xs font-medium transition-colors flex items-center justify-center gap-2"
              >
                <Save className="w-3 h-3" />
                {texts.updateBtn}
              </button>
            </div>
          ) : (
            // ADD NEW PRESET FORM
            <div className="flex gap-2 mb-4">
              <input
                type="text"
                value={newPresetName}
                onChange={(e) => setNewPresetName(e.target.value)}
                placeholder={texts.savePresetPlaceholder}
                className="flex-1 bg-gray-50 dark:bg-dark-800 border border-gray-200 dark:border-dark-700 rounded-lg px-3 py-2 text-sm text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:border-primary-500"
              />
              <button
                onClick={handleSave}
                disabled={!newPresetName.trim()}
                className="bg-primary-600 hover:bg-primary-500 disabled:opacity-50 disabled:cursor-not-allowed text-white p-2 rounded-lg transition-colors"
                title={texts.saveBtn}
              >
                <Save className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Presets List */}
          <div className="space-y-1 max-h-48 overflow-y-auto pr-1 custom-scrollbar">
            {presets.length === 0 ? (
              <p className="text-gray-500 text-center text-sm py-2">{texts.noPresets}</p>
            ) : (
              presets.map(preset => (
                <div
                  key={preset.id}
                  className={`
                    w-full flex items-center justify-between group p-2 rounded-lg transition-colors border border-transparent
                    ${editingId === preset.id ? 'bg-primary-50 dark:bg-primary-900/20 border-primary-200 dark:border-primary-800' : 'hover:bg-gray-100 dark:hover:bg-dark-800'}
                  `}
                >
                  <button
                    onClick={() => {
                      if (editingId !== preset.id) {
                        onSelect(preset);
                        setIsOpen(false);
                      }
                    }}
                    className="flex-1 flex flex-col overflow-hidden text-left"
                  >
                    <span className="text-sm text-gray-800 dark:text-gray-200 font-medium truncate">{preset.name}</span>
                    <span className="text-xs text-gray-500 truncate">
                      {preset.language.toUpperCase()} • {preset.complexity}
                      {preset.customStyle && ` • ${preset.customStyle}`}
                    </span>
                  </button>
                  
                  <div className="flex items-center gap-1">
                     {/* Edit Button */}
                     <button
                       onClick={(e) => startEdit(preset, e)}
                       className={`
                         p-1.5 text-gray-400 hover:text-primary-500 dark:hover:text-primary-400 transition-all rounded
                         ${editingId === preset.id ? 'text-primary-500' : 'opacity-0 group-hover:opacity-100'}
                       `}
                       title={texts.editPreset}
                     >
                       <Pencil className="w-3.5 h-3.5" />
                     </button>
                     
                     {/* Delete Button */}
                     <button 
                       onClick={(e) => handleDelete(preset.id, e)}
                       className="p-1.5 text-gray-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all rounded"
                     >
                       <Trash2 className="w-3.5 h-3.5" />
                     </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default PresetSelector;
