
import React from 'react';
import { GALLERY_ITEMS } from '../constants';
import { GalleryItem, Translations } from '../types';
import { Sparkles, ArrowRight } from 'lucide-react';

interface Props {
  onSelect: (item: GalleryItem) => void;
  texts: Translations;
}

const Gallery: React.FC<Props> = ({ onSelect, texts }) => {
  return (
    <div className="w-full mt-10 animate-fade-in">
      <div className="flex items-center gap-2 mb-4 px-2">
        <Sparkles className="w-5 h-5 text-primary-500" />
        <h3 className="text-xl font-bold text-gray-800 dark:text-gray-200">
          {texts.galleryTitle}
        </h3>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {GALLERY_ITEMS.map((item) => (
          <button
            key={item.id}
            onClick={() => onSelect(item)}
            className="group relative rounded-xl overflow-hidden border border-gray-200 dark:border-dark-700 shadow-md hover:shadow-xl transition-all duration-300 bg-white dark:bg-dark-800 text-left h-48 sm:h-56"
          >
            <img 
              src={item.src} 
              alt={item.alt}
              className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
            
            {/* Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />
            
            <div className="absolute bottom-0 left-0 p-4 w-full">
              <span className="text-xs font-bold text-primary-300 uppercase tracking-wider mb-1 block">
                {item.style}
              </span>
              <div className="flex items-center justify-between text-white">
                <span className="text-sm font-medium truncate pr-2">
                  {item.alt}
                </span>
                <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transform translate-x-[-10px] group-hover:translate-x-0 transition-all duration-300" />
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};

export default Gallery;
