
import React, { useState } from 'react';
import { Crown, Sparkles, Zap, X, Check, ShoppingCart, Lock } from 'lucide-react';
import { Translations } from '../types';
import { PAYMENT_LINK, VALID_LICENSE_KEY } from '../constants';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onUpgrade: () => void;
  texts: Translations;
}

const PremiumModal: React.FC<Props> = ({ isOpen, onClose, onUpgrade, texts }) => {
  const [licenseKey, setLicenseKey] = useState('');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleUnlock = () => {
    if (licenseKey.trim() === VALID_LICENSE_KEY) {
      onUpgrade();
      onClose();
      setLicenseKey('');
      setError('');
    } else {
      setError(texts.invalidCode);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-dark-900 border border-yellow-500/30 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden relative animate-in zoom-in-95 duration-300">
        
        {/* Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-white/80 hover:text-white transition-colors z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header with Gradient */}
        <div className="bg-gradient-to-br from-yellow-600 via-yellow-800 to-yellow-950 dark:from-yellow-900/40 dark:via-dark-900 dark:to-dark-900 p-8 text-center relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-yellow-400 to-transparent opacity-50"></div>
          <div className="inline-flex items-center justify-center p-4 bg-yellow-500/20 rounded-full mb-4 border border-yellow-500/50 shadow-lg shadow-yellow-500/20">
            <Crown className="w-8 h-8 text-yellow-200 dark:text-yellow-400" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">{texts.premiumModalTitle}</h2>
        </div>

        {/* Benefits List */}
        <div className="p-8 pt-6 space-y-6">
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="mt-1 bg-yellow-100 dark:bg-yellow-500/10 p-1.5 rounded-full">
                <Sparkles className="w-5 h-5 text-yellow-600 dark:text-yellow-400" />
              </div>
              <p className="text-gray-700 dark:text-gray-300 text-lg">{texts.premiumBenefit1}</p>
            </div>
            <div className="flex items-start gap-3">
              <div className="mt-1 bg-yellow-100 dark:bg-yellow-500/10 p-1.5 rounded-full">
                <Check className="w-5 h-5 text-yellow-600 dark:text-yellow-400" />
              </div>
              <p className="text-gray-700 dark:text-gray-300 text-lg">{texts.premiumBenefit2}</p>
            </div>
            <div className="flex items-start gap-3">
              <div className="mt-1 bg-yellow-100 dark:bg-yellow-500/10 p-1.5 rounded-full">
                <Zap className="w-5 h-5 text-yellow-600 dark:text-yellow-400" />
              </div>
              <p className="text-gray-700 dark:text-gray-300 text-lg">{texts.premiumBenefit3}</p>
            </div>
          </div>

          {/* Action Button - Buy */}
          <div>
            <a
              href={PAYMENT_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-4 bg-gradient-to-r from-yellow-500 to-yellow-400 hover:from-yellow-400 hover:to-yellow-300 text-black font-bold text-lg rounded-xl shadow-lg shadow-yellow-500/20 transition-all transform hover:scale-[1.02] flex items-center justify-center gap-2 mb-2"
            >
              <ShoppingCart className="w-5 h-5" />
              {texts.upgradeBtn}
            </a>
            <p className="text-center text-xs text-gray-500 dark:text-gray-400 flex items-center justify-center gap-1.5">
              <Lock className="w-3 h-3" /> {texts.securePayment}
            </p>
          </div>

          {/* Separator */}
          <div className="relative py-2">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t border-gray-200 dark:border-dark-700"></span>
            </div>
          </div>

          {/* Activation Code Section */}
          <div className="space-y-3">
            <p className="text-sm text-gray-500 dark:text-gray-400">{texts.haveCode}</p>
            <div className="flex gap-2">
              <div className="relative flex-grow">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input 
                  type="text" 
                  value={licenseKey}
                  onChange={(e) => setLicenseKey(e.target.value)}
                  placeholder={texts.enterCode}
                  className="w-full bg-gray-50 dark:bg-dark-800 border border-gray-200 dark:border-dark-700 text-gray-900 dark:text-white text-sm rounded-lg pl-10 pr-3 py-2.5 focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500"
                />
              </div>
              <button 
                onClick={handleUnlock}
                className="bg-gray-200 dark:bg-dark-700 hover:bg-gray-300 dark:hover:bg-dark-600 text-gray-900 dark:text-white px-4 py-2 rounded-lg font-medium text-sm transition-colors border border-gray-300 dark:border-dark-600"
              >
                {texts.unlockBtn}
              </button>
            </div>
            {error && <p className="text-red-500 dark:text-red-400 text-xs">{error}</p>}
          </div>

        </div>
      </div>
    </div>
  );
};

export default PremiumModal;