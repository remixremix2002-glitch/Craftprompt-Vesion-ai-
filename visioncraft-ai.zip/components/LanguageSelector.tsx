
import React, { useState, useRef, useEffect } from 'react';
import { Language } from '../types';
import { Globe, ChevronDown, Check } from 'lucide-react';
import { REGIONS } from '../constants';

interface Props {
  currentLang: Language;
  onChange: (lang: Language) => void;
}

const LanguageSelector: React.FC<Props> = ({ currentLang, onChange }) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const currentLangConfig = REGIONS.flatMap(r => r.langs).find(l => l.code === currentLang);

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`
          flex items-center gap-2 px-3 py-2 rounded-lg border transition-all duration-200 shadow-sm
          ${isOpen 
            ? 'bg-white dark:bg-dark-800 border-primary-500 text-gray-900 dark:text-white' 
            : 'bg-white/50 dark:bg-dark-800/50 border-gray-200 dark:border-dark-700 text-gray-600 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-dark-700'}
        `}
      >
        <Globe className="w-4 h-4 text-primary-500 dark:text-primary-400" />
        <span className="text-sm font-medium mr-1 hidden sm:inline-block">
          {currentLangConfig?.label.split('(')[0] || 'Language'}
        </span>
        <span className="text-sm sm:hidden">
           {currentLang.toUpperCase()}
        </span>
        <ChevronDown className={`w-3 h-3 text-gray-500 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-64 bg-white dark:bg-dark-900 border border-gray-200 dark:border-dark-700 rounded-xl shadow-2xl z-50 max-h-[80vh] overflow-y-auto animate-in fade-in slide-in-from-top-2 ring-1 ring-black/5 dark:ring-white/5">
          <div className="p-2 space-y-1">
            {REGIONS.map((group) => (
              <div key={group.region}>
                <div className="px-3 py-2 text-[10px] font-bold text-gray-500 dark:text-gray-400 uppercase tracking-widest bg-gray-100 dark:bg-dark-800/50 rounded mt-1 mb-1 first:mt-0">
                  {group.region}
                </div>
                {group.langs.map((lang) => {
                   const isActive = currentLang === lang.code;
                   return (
                    <button
                      key={lang.code}
                      onClick={() => {
                        onChange(lang.code);
                        setIsOpen(false);
                      }}
                      className={`
                        w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm transition-all duration-150
                        ${isActive 
                          ? 'bg-primary-50 dark:bg-primary-600/10 text-primary-600 dark:text-primary-400 font-medium' 
                          : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-dark-800 hover:text-gray-900 dark:hover:text-white'}
                      `}
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-lg leading-none filter drop-shadow-sm">{lang.flag}</span>
                        <span>{lang.label}</span>
                      </div>
                      {isActive && <Check className="w-4 h-4" />}
                    </button>
                   );
                })}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default LanguageSelector;